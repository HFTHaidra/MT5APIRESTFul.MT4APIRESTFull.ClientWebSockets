﻿using System.Net.WebSockets;
using System.Text;

Console.Title = "[HFTHaidra@gmail.com] ClientWebSocket";

using var ws = new ClientWebSocket(); 
//URL = "ws://localhost:5050/ws?Sub=OnQuote?id=56bcd13e-f5fb-441b-a28b-d8e7a72dbd68sbxsy8g78wtedx67w9edgc08ew";

string TimeMilliseconds()
{
    return System.DateTimeOffset.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
}




string URL = "ws://localhost:5030/ws?Sub=OnQuote?id=56bcd13e-f5fb-441b-a28b-d8e7a72dbd68sbxsy8g78wtedx67w9edgc08ew";


string ID = "ID";
Console.WriteLine("built-in WebSocket Test client..");
Console.WriteLine("URL EX:");
Console.WriteLine($"ws://localhost:5030/OnQuote?id={ID}");
ID = "56bcd13e-f5fb-441b-a28b-d8e7a72dbd68sbxsy8g78wtedx67w9edgc08ew";
Console.WriteLine($"ws://localhost:5030/OnQuote?id={ID}");
Console.WriteLine("Socket URL:");

URL = Console.ReadLine();

 

Console.WriteLine("URL => " + URL);
Thread.Sleep(1000);
try
{
    await ws.ConnectAsync(new Uri(URL), CancellationToken.None);
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message + "\n");
}



byte[] buf = new byte[1056];

while (ws.State == WebSocketState.Open)
{
    try
    {
        
        var result = await ws.ReceiveAsync(buf, CancellationToken.None);
        if (result.MessageType == WebSocketMessageType.Close)
        {
            await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, null, CancellationToken.None);
            Console.WriteLine(result.CloseStatusDescription);
        }
        else
        {
            Console.WriteLine(Encoding.ASCII.GetString(buf, 0, result.Count));
        }

    }catch (Exception ex)
    {
        Console.WriteLine(ex.ToString());
        Console.ReadKey();
    }
   

    
}


